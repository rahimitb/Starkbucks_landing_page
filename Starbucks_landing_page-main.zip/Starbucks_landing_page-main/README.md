# Starbucks_landing_page
Starbucks' landing page invites you into a world of aromatic blends and cozy ambiance, promising a delightful coffee experience just a click away
visit website: https://ritesh-0309.github.io/Starbucks_landing_page/
